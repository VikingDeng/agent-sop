# Open Quality independent Pilot runner

This directory is deliberately outside the candidate `agent-sop` repository.
It is an evaluator asset, not another SOP runtime component.

The first formal command is fail-closed:

```bash
python3 -m open_quality_runner preflight
python3 -m open_quality_runner readiness
```

It must prove a fresh mount/network namespace that can expose only a per-slot
Codex home and project while hiding candidate source, Oracles, assignments,
other arms, and prior outputs. A `NO_GO` result forbids formal A/B/C samples;
there is no force flag. The current ChatGPT Work container is expected to fail
this probe because nested namespace creation is disabled.

The runner pins the candidate tree identity as:

```text
SHA-256 of the exact bytes emitted by:
git ls-tree -r -z --full-tree REV
```

The collector refuses incomplete model attribution and adds separately reported
system/guardian token overhead to `25*T_sol + 10*T_terra + 1*T_luna`.

The evaluator package contains external fixture Oracles, a schema subset
validator, artifact normalization, and the fixed product browser journey. None
of those files may be mounted into an Agent slot. Formal orchestration remains
blocked until a trusted runner passes preflight and supplies 48 independent
fresh HOME/session slots.

## Why the local chroot probe is not a formal backend

A successful copy-only chroot probe demonstrated that Codex can write a task
while the candidate source and evaluator paths are absent.  Independent
canaries also demonstrated why that is not enough: a same-UID, zero-capability
process can still signal host processes and connect to host loopback, and an
inherited directory file descriptor can escape a chroot.  Formal readiness
therefore requires all of the following, not merely path hiding:

- a filesystem namespace, container, or VM exposing only one slot;
- a PID namespace or slot-specific UID;
- kernel-enforced default-deny task networking;
- brokered or two-phase authentication that is gone before Agent tools run;
- file-descriptor scrubbing for the Codex process and every tool child.

`readiness` reports `NO_GO` until those independent controls are present. It
has no force flag and never turns dry-run evidence into a formal A/B/C sample.

The contract can still be frozen without consuming a sample:

```bash
python3 -m open_quality_runner freeze-pilot \
  ../agent-sop evidence/frozen-pilot --seed '<independently generated seed>'
```

This produces the 12 routing prompts, four deterministic outcome ZIPs,
baseline/candidate treatment archives and tree receipts, permissions, and a
concealed blocked assignment plan. Its status is `FROZEN_NOT_RUN`; it cannot
substitute for `readiness`, a trace, an Oracle result, or a blind review.
