# Pilot handoff — 2026-08-13

## Frozen decision

- Candidate treatment: `agent-sop@10dafa87d2b4d20b265ef260e73afdf7799d6548`.
- Baseline treatment: `agent-sop@497b5ba436a1a0392af01db3f2fecd3aa53e95e9`.
- Root model/effort for every arm: `gpt-5.6-sol` / `high`.
- Pilot scope: 12 routing cases and four outcome fixtures, one A/B/C repetition.
- Promotion remains forbidden until an independently authenticated Pilot passes.

## Current verdict

`FROZEN_NOT_RUN` / `NO_GO` in the current managed workspace.

The Codex CLI, ChatGPT authentication, JSONL event stream, preserved sessions,
and WCU audit path were exercised successfully. The current host cannot create
the independent PID/network/filesystem boundary required by the study. A
copy-only chroot hides paths but can still signal same-UID host processes,
reach host loopback, and escape through a leaked directory file descriptor.
No A/B/C result produced under that boundary may enter Pilot evidence.

## Next executable action

Run `python3 -m open_quality_runner readiness` on a trusted runner that gives
each slot its own container or VM, PID namespace or UID, default-deny task
network, credential broker/two-phase handoff, and tool-child FD scrubbing. Only
after it returns `GO` may that runner consume the committed frozen package.

The first hard kill stops the Pilot. A no-lift result disables or deletes the
candidate treatment. A passing independently authenticated Pilot authorizes
the full three-repetition promotion study and mechanism ablations; it does not
itself promote the candidate.
