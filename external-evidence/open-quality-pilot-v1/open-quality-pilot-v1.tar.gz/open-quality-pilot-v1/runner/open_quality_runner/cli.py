"""CLI for independent Open Quality Pilot preflight and evidence collection."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .core import (
    RunnerError,
    canonical_tree_sha256,
    collect_wcu,
    isolation_preflight,
    readiness_report,
)
from .study import freeze_pilot


def emit(value: object) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("preflight")
    commands.add_parser("readiness")
    freeze = commands.add_parser("freeze-pilot")
    freeze.add_argument("checkout", type=Path)
    freeze.add_argument("output", type=Path)
    freeze.add_argument("--seed", required=True)
    freeze.add_argument("--model", default="gpt-5.6-sol")
    freeze.add_argument("--effort", default="high")
    tree = commands.add_parser("tree-sha256")
    tree.add_argument("checkout", type=Path)
    tree.add_argument("revision")
    wcu = commands.add_parser("collect-wcu")
    wcu.add_argument("audit", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command == "preflight":
            report = isolation_preflight()
            emit(report)
            return 0 if report["status"] == "PASS" else 2
        if args.command == "readiness":
            report = readiness_report()
            emit(report)
            return 0 if report["status"] == "GO" else 2
        if args.command == "freeze-pilot":
            report = freeze_pilot(
                args.checkout,
                args.output,
                seed=args.seed,
                model=args.model,
                effort=args.effort,
            )
            emit(report)
            return 0
        if args.command == "tree-sha256":
            emit({"algorithm": "sha256(git ls-tree -r -z --full-tree REV)", "sha256": canonical_tree_sha256(args.checkout, args.revision)})
            return 0
        audit = json.loads(args.audit.read_text(encoding="utf-8"))
        emit(collect_wcu(audit))
        return 0
    except (OSError, json.JSONDecodeError, RunnerError) as error:
        emit({"status": "NO_GO", "error": str(error)})
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
