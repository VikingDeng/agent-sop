"""Evaluator-only outcome checks for the open-quality pilot.

Nothing from this package belongs in an Agent-visible slot.
"""

from .api import EvaluationError, evaluate_run, normalize_blind_bundle

__all__ = ["EvaluationError", "evaluate_run", "normalize_blind_bundle"]
