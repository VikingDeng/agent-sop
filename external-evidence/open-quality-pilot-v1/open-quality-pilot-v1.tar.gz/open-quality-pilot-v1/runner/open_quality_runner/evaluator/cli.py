"""One machine-readable CLI for external Open Quality evaluation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .api import EVALUATION_VERSION, evaluate_run, normalize_blind_bundle
from .io import EvaluationError, read_json, write_json
from .oracle import run_oracle
from .schema import validate_files


def _emit(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def _status_exit(report: dict[str, Any]) -> int:
    if report.get("status") == "PASS":
        return 0
    if report.get("status") == "INVALID":
        return 2
    return 1


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run evaluator-owned Open Quality checks")
    commands = parser.add_subparsers(dest="command", required=True)

    evaluate = commands.add_parser("evaluate", help="run every mandatory check for a fixture")
    evaluate.add_argument("fixture_root", type=Path)
    evaluate.add_argument("candidate_root", type=Path)
    evaluate.add_argument("--submission", type=Path)
    evaluate.add_argument("--pristine-root", type=Path)
    evaluate.add_argument("--evidence-root", type=Path)
    evaluate.add_argument("--node-command", default="node")
    evaluate.add_argument("--browser-executable", type=Path)
    evaluate.add_argument("--oracle-timeout", type=int, default=60)
    evaluate.add_argument("--browser-timeout", type=int, default=90)
    evaluate.add_argument("--output", type=Path)

    oracle = commands.add_parser("oracle", help="run only the external fixture Oracle")
    oracle.add_argument("fixture_root", type=Path)
    oracle.add_argument("candidate_root", type=Path)
    oracle.add_argument("--submission", type=Path)
    oracle.add_argument("--pristine-root", type=Path)
    oracle.add_argument("--timeout", type=int, default=60)

    schema = commands.add_parser("schema", help="validate a JSON instance against a frozen schema")
    schema.add_argument("instance", type=Path)
    schema.add_argument("schema", type=Path)

    blind = commands.add_parser("normalize-blind", help="remove runtime identity from a JSON report")
    blind.add_argument("input", type=Path)
    blind.add_argument("--output", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "evaluate":
            report = evaluate_run(
                args.fixture_root,
                args.candidate_root,
                submission=args.submission,
                pristine_root=args.pristine_root,
                evidence_root=args.evidence_root,
                node_command=args.node_command,
                browser_executable=args.browser_executable,
                oracle_timeout_seconds=args.oracle_timeout,
                browser_timeout_seconds=args.browser_timeout,
            )
            if args.output is not None:
                write_json(args.output, report)
        elif args.command == "oracle":
            report = run_oracle(
                args.fixture_root,
                args.candidate_root,
                submission=args.submission,
                pristine_root=args.pristine_root,
                timeout_seconds=args.timeout,
            )
        elif args.command == "schema":
            report = {"version": EVALUATION_VERSION, "check": "json_schema", **validate_files(args.instance, args.schema)}
        else:
            value = read_json(args.input)
            if not isinstance(value, dict):
                raise EvaluationError("blind bundle input must be a JSON object")
            report = normalize_blind_bundle(value)
            if args.output is not None:
                write_json(args.output, report)
        _emit(report)
        if args.command == "normalize-blind":
            return 0
        return _status_exit(report)
    except (EvaluationError, OSError, ValueError) as error:
        _emit({"version": EVALUATION_VERSION, "status": "INVALID", "error": str(error)})
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
