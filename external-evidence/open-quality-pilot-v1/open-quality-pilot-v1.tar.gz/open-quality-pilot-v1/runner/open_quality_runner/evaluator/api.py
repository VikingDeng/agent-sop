"""Public, evaluator-owned API for one complete fixture evaluation."""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Mapping

from .browser import run_product_browser
from .io import EvaluationError, expect_mapping, read_json
from .oracle import run_oracle
from .schema import validate_files


EVALUATION_VERSION = "open-quality-evaluation-v1"
SUPPORTED_FIXTURES = {"out_product_02", "out_idea_01", "out_research_02", "out_simple_02"}
SCHEMA_FIXTURES = {"out_idea_01", "out_research_02"}


def _fixture_id(fixture_root: Path) -> str:
    manifest = expect_mapping(read_json(fixture_root / "fixture.json"), "fixture manifest")
    fixture_id = manifest.get("outcome_id")
    if not isinstance(fixture_id, str) or fixture_id not in SUPPORTED_FIXTURES:
        raise EvaluationError(f"unsupported outcome fixture: {fixture_id!r}")
    return fixture_id


def _combined_status(checks: Mapping[str, Mapping[str, Any]]) -> str:
    statuses = [check.get("status") for check in checks.values()]
    if any(status == "INVALID" for status in statuses):
        return "INVALID"
    return "PASS" if statuses and all(status == "PASS" for status in statuses) else "FAIL"


def evaluate_run(
    fixture_root: Path,
    candidate_root: Path,
    *,
    submission: Path | None = None,
    pristine_root: Path | None = None,
    evidence_root: Path | None = None,
    node_command: str = "node",
    browser_executable: Path | None = None,
    oracle_timeout_seconds: int = 60,
    browser_timeout_seconds: int = 90,
) -> dict[str, Any]:
    """Run every mandatory evaluator check for a materialized pilot fixture.

    Oracles and schemas are always loaded from ``fixture_root`` rather than the
    candidate tree.  Product evaluations always include the browser journey;
    there is deliberately no API option that silently skips it.
    """

    fixture_root = Path(fixture_root).resolve(strict=True)
    candidate_root = Path(candidate_root).resolve(strict=True)
    if not fixture_root.is_dir() or not candidate_root.is_dir():
        raise EvaluationError("fixture_root and candidate_root must be directories")
    fixture_id = _fixture_id(fixture_root)
    resolved_submission = Path(submission).resolve(strict=True) if submission is not None else None
    if fixture_id in SCHEMA_FIXTURES:
        resolved_submission = resolved_submission or (candidate_root / "submission.json")
        if not resolved_submission.is_file():
            raise EvaluationError(f"submission does not exist: {resolved_submission}")

    checks: dict[str, dict[str, Any]] = {}
    if fixture_id in SCHEMA_FIXTURES:
        schema_path = fixture_root / "workspace" / "submission.schema.json"
        if not schema_path.is_file():
            # A copied schema in the candidate tree is not evaluator-trusted.
            raise EvaluationError(f"fixture schema does not exist: {schema_path}")
        schema_report = validate_files(resolved_submission, schema_path)  # type: ignore[arg-type]
        checks["json_schema"] = {
            **schema_report,
            "schema": "workspace/submission.schema.json",
        }

    checks["oracle"] = run_oracle(
        fixture_root,
        candidate_root,
        submission=resolved_submission,
        pristine_root=Path(pristine_root).resolve(strict=True) if pristine_root is not None else None,
        timeout_seconds=oracle_timeout_seconds,
    )

    if fixture_id == "out_product_02":
        resolved_evidence = (
            Path(evidence_root).resolve()
            if evidence_root is not None
            else candidate_root.parent / f"{candidate_root.name}-browser-evidence"
        )
        checks["product_journey"] = run_product_browser(
            candidate_root,
            resolved_evidence,
            node_command=node_command,
            browser_executable=browser_executable,
            timeout_seconds=browser_timeout_seconds,
        )

    return {
        "version": EVALUATION_VERSION,
        "fixture": fixture_id,
        "status": _combined_status(checks),
        "checks": checks,
    }


def normalize_blind_bundle(bundle: Mapping[str, Any]) -> dict[str, Any]:
    """Return a detached evaluation summary suitable for a blind reviewer.

    Runtime identity and local-machine paths are process evidence, not outcome
    quality evidence.  The function removes those known fields recursively and
    never mutates the caller's mapping.  Oracle, schema, browser steps, hashes,
    console/network events and screenshots remain available to review.
    """

    if not isinstance(bundle, Mapping):
        raise EvaluationError("blind bundle must be a mapping")
    hidden = {
        "agent_id",
        "arm",
        "candidate_root",
        "fixture_root",
        "model",
        "session_id",
        "slot_id",
    }

    def scrub(value: Any) -> Any:
        if isinstance(value, Mapping):
            return {str(key): scrub(item) for key, item in value.items() if key not in hidden}
        if isinstance(value, list):
            return [scrub(item) for item in value]
        if isinstance(value, tuple):
            return [scrub(item) for item in value]
        return copy.deepcopy(value)

    normalized = scrub(bundle)
    if not isinstance(normalized, dict):  # guarded above; keeps the return contract explicit
        raise EvaluationError("blind bundle normalization failed")
    return normalized
