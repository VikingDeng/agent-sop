"""Dependency-free JSON Schema subset used by frozen fixture submissions.

The supported keywords are exactly the ones used by the pilot's idea and
research schemas. Unknown validation keywords fail closed.
"""

from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any

from .io import EvaluationError, read_json


ANNOTATION_KEYS = {"$schema", "$id", "title", "description", "default", "examples"}
SUPPORTED_KEYS = {
    "type",
    "enum",
    "required",
    "properties",
    "additionalProperties",
    "items",
    "minItems",
    "maxItems",
    "minLength",
    "maxLength",
    "pattern",
    "minimum",
    "maximum",
}


def _type_matches(value: Any, expected: str) -> bool:
    if expected == "null":
        return value is None
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return (
            isinstance(value, int)
            and not isinstance(value, bool)
            or isinstance(value, float)
            and math.isfinite(value)
        )
    raise EvaluationError(f"unsupported JSON Schema type: {expected}")


def _validate_keywords(schema: dict[str, Any], location: str) -> None:
    unknown = set(schema) - ANNOTATION_KEYS - SUPPORTED_KEYS
    if unknown:
        raise EvaluationError(f"unsupported JSON Schema keywords at {location}: {sorted(unknown)}")


def _schema_error(message: str, location: str) -> EvaluationError:
    return EvaluationError(f"{message} at {location}")


def _json_equal(left: Any, right: Any) -> bool:
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return left == right
    if type(left) is not type(right):
        return False
    if isinstance(left, list):
        return len(left) == len(right) and all(_json_equal(a, b) for a, b in zip(left, right))
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(_json_equal(left[key], right[key]) for key in left)
    return left == right


def _check_schema(schema: dict[str, Any], location: str) -> None:
    """Validate the schema vocabulary before using it.

    The evaluator intentionally implements only the vocabulary frozen in the
    two pilot schemas.  Validating the schema itself avoids Python coercions
    (for example ``True == 1``) turning a malformed schema into a passing one.
    """

    _validate_keywords(schema, location)
    declared_type = schema.get("type")
    if declared_type is not None:
        choices = [declared_type] if isinstance(declared_type, str) else declared_type
        known = {"null", "object", "array", "string", "boolean", "integer", "number"}
        if (
            not isinstance(choices, list)
            or not choices
            or not all(isinstance(item, str) and item in known for item in choices)
            or len(set(choices)) != len(choices)
        ):
            raise _schema_error("invalid type declaration", location)
    if "enum" in schema:
        enum = schema["enum"]
        if not isinstance(enum, list) or not enum:
            raise _schema_error("enum must be a non-empty array", location)
        if any(_json_equal(enum[left], enum[right]) for left in range(len(enum)) for right in range(left + 1, len(enum))):
            raise _schema_error("enum entries must be unique", location)
    required = schema.get("required", [])
    if not isinstance(required, list) or not all(isinstance(item, str) for item in required):
        raise _schema_error("required must be an array of strings", location)
    if len(set(required)) != len(required):
        raise _schema_error("required entries must be unique", location)
    properties = schema.get("properties", {})
    if not isinstance(properties, dict):
        raise _schema_error("properties must be an object", location)
    for name, child in properties.items():
        if not isinstance(name, str) or not isinstance(child, dict):
            raise _schema_error("property schemas must be objects", f"{location}.properties")
        _check_schema(child, f"{location}.properties.{name}")
    additional = schema.get("additionalProperties", True)
    if not isinstance(additional, (bool, dict)):
        raise _schema_error("additionalProperties must be boolean or schema", location)
    if isinstance(additional, dict):
        _check_schema(additional, f"{location}.additionalProperties")
    items = schema.get("items")
    if items is not None:
        if not isinstance(items, dict):
            raise _schema_error("items must be a schema", location)
        _check_schema(items, f"{location}.items")
    for keyword in ("minItems", "maxItems", "minLength", "maxLength"):
        if keyword in schema and (
            not isinstance(schema[keyword], int)
            or isinstance(schema[keyword], bool)
            or schema[keyword] < 0
        ):
            raise _schema_error(f"{keyword} must be a non-negative integer", location)
    for minimum, maximum in (("minItems", "maxItems"), ("minLength", "maxLength")):
        if minimum in schema and maximum in schema and schema[minimum] > schema[maximum]:
            raise _schema_error(f"{minimum} cannot exceed {maximum}", location)
    for keyword in ("minimum", "maximum"):
        value = schema.get(keyword)
        if keyword in schema and (
            not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not math.isfinite(value)
        ):
            raise _schema_error(f"{keyword} must be a finite number", location)
    if "minimum" in schema and "maximum" in schema and schema["minimum"] > schema["maximum"]:
        raise _schema_error("minimum cannot exceed maximum", location)
    if "pattern" in schema:
        if not isinstance(schema["pattern"], str):
            raise _schema_error("pattern must be a string", location)
        try:
            re.compile(schema["pattern"])
        except re.error as error:
            raise _schema_error(f"invalid regular expression: {error}", location) from error


def validate(instance: Any, schema: dict[str, Any], location: str = "$") -> list[str]:
    if not isinstance(schema, dict):
        raise EvaluationError(f"schema must be an object at {location}")
    _check_schema(schema, location)
    errors: list[str] = []
    expected = schema.get("type")
    if expected is not None:
        choices = [expected] if isinstance(expected, str) else expected
        if not any(_type_matches(instance, item) for item in choices):
            return [f"{location}: expected type {choices}, got {type(instance).__name__}"]

    if "enum" in schema and not any(_json_equal(instance, choice) for choice in schema["enum"]):
        errors.append(f"{location}: value is not in enum")

    if isinstance(instance, dict):
        required = schema.get("required", [])
        for name in required:
            if name not in instance:
                errors.append(f"{location}: missing required property {name!r}")
        properties = schema.get("properties", {})
        extra = set(instance) - set(properties)
        additional = schema.get("additionalProperties", True)
        if additional is False:
            for name in sorted(extra):
                errors.append(f"{location}: unexpected property {name!r}")
        elif isinstance(additional, dict):
            for name in sorted(extra):
                errors.extend(validate(instance[name], additional, f"{location}.{name}"))
        for name, child_schema in properties.items():
            if name in instance:
                errors.extend(validate(instance[name], child_schema, f"{location}.{name}"))

    if isinstance(instance, list):
        minimum = schema.get("minItems")
        maximum = schema.get("maxItems")
        if minimum is not None and len(instance) < minimum:
            errors.append(f"{location}: fewer than {minimum} items")
        if maximum is not None and len(instance) > maximum:
            errors.append(f"{location}: more than {maximum} items")
        items = schema.get("items")
        if items is not None:
            for index, item in enumerate(instance):
                errors.extend(validate(item, items, f"{location}[{index}]"))

    if isinstance(instance, str):
        if "minLength" in schema and len(instance) < schema["minLength"]:
            errors.append(f"{location}: shorter than {schema['minLength']} characters")
        if "maxLength" in schema and len(instance) > schema["maxLength"]:
            errors.append(f"{location}: longer than {schema['maxLength']} characters")
        if "pattern" in schema and re.search(schema["pattern"], instance) is None:
            errors.append(f"{location}: does not match pattern {schema['pattern']!r}")

    if isinstance(instance, (int, float)) and not isinstance(instance, bool):
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append(f"{location}: below minimum {schema['minimum']}")
        if "maximum" in schema and instance > schema["maximum"]:
            errors.append(f"{location}: above maximum {schema['maximum']}")
    return errors


def validate_files(instance_path: Path, schema_path: Path) -> dict[str, Any]:
    instance = read_json(instance_path)
    schema_value = read_json(schema_path)
    if not isinstance(schema_value, dict):
        raise EvaluationError(f"schema must be an object: {schema_path}")
    errors = validate(instance, schema_value)
    return {"status": "PASS" if not errors else "FAIL", "errors": errors}
