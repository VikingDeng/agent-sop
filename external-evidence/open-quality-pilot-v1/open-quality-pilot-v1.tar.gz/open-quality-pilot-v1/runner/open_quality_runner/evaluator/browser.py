"""Start a candidate product server and run the fixed Playwright journey."""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any
from urllib.request import urlopen

from .io import EvaluationError, file_receipt, read_json


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as connection:
        connection.bind(("127.0.0.1", 0))
        return int(connection.getsockname()[1])


def _wait_ready(url: str, process: subprocess.Popen[str], timeout: float = 10.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise EvaluationError(f"candidate server exited before readiness: {process.returncode}")
        try:
            with urlopen(url, timeout=0.5) as response:
                if response.status == 200:
                    return
        except OSError:
            time.sleep(0.1)
    raise EvaluationError(f"candidate server did not become ready: {url}")


def _last_json(stdout: str) -> dict[str, Any]:
    for line in reversed(stdout.splitlines()):
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    raise EvaluationError("browser journey emitted no JSON")


def run_product_browser(
    candidate_root: Path,
    evidence_root: Path,
    node_command: str = "node",
    browser_executable: Path | None = None,
    timeout_seconds: int = 90,
) -> dict[str, Any]:
    candidate_root = candidate_root.resolve(strict=True)
    evidence_root.mkdir(parents=True, exist_ok=True)
    for name in ("browser-report.json", "console.json", "requests.json"):
        stale = evidence_root / name
        if stale.exists():
            stale.unlink()
    journey = Path(__file__).with_name("product_journey.mjs")
    port = _free_port()
    base_url = f"http://127.0.0.1:{port}"
    environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    with tempfile.TemporaryDirectory(prefix="product-data-") as temporary:
        temporary_data = Path(temporary) / "data"
        shutil.copytree(candidate_root / "data", temporary_data)
        environment["EXPERIMENT_DATA_DIR"] = str(temporary_data)
        server_log = evidence_root / "server.log"
        with server_log.open("w", encoding="utf-8") as server_handle:
            server = subprocess.Popen(
                [sys.executable, "app.py", "--port", str(port)],
                cwd=candidate_root,
                env=environment,
                text=True,
                stdout=server_handle,
                stderr=subprocess.STDOUT,
            )
            try:
                _wait_ready(base_url, server)
                command = [node_command, str(journey), "--base-url", base_url, "--output-dir", str(evidence_root)]
                if browser_executable is not None:
                    command.extend(["--browser-executable", str(browser_executable)])
                try:
                    process = subprocess.run(
                        command,
                        env=environment,
                        text=True,
                        capture_output=True,
                        timeout=timeout_seconds,
                        check=False,
                    )
                except (OSError, subprocess.TimeoutExpired) as error:
                    raise EvaluationError(f"browser journey failed to execute: {error}") from error
            finally:
                server.terminate()
                try:
                    server.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait(timeout=3)

    report_path = evidence_root / "browser-report.json"
    if report_path.exists():
        report = read_json(report_path)
    else:
        try:
            report = _last_json(process.stdout)
        except EvaluationError:
            report = {
                "version": "product-journey-v2",
                "status": "INVALID",
                "error": "browser journey produced no report",
            }
    evidence_files = [path for path in sorted(evidence_root.iterdir()) if path.is_file()]
    journey_status = report.get("status")
    return {
        "status": (
            "PASS"
            if process.returncode == 0 and journey_status == "PASS"
            else "INVALID"
            if process.returncode == 2 or journey_status == "INVALID"
            else "FAIL"
        ),
        "exit_code": process.returncode,
        "report": report,
        "stderr_tail": process.stderr[-2000:],
        "evidence": [file_receipt(path, evidence_root) for path in evidence_files],
    }
