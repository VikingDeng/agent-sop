#!/usr/bin/env node
/* Fixed, evaluator-owned product journey. Never copy this file into a slot. */

import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);

function argument(name) {
  const index = process.argv.indexOf(name);
  if (index < 0 || index + 1 >= process.argv.length) throw new Error(`missing ${name}`);
  return process.argv[index + 1];
}

const baseUrl = argument("--base-url").replace(/\/$/, "");
const outputDir = path.resolve(argument("--output-dir"));
const executablePath = process.argv.includes("--browser-executable")
  ? argument("--browser-executable")
  : undefined;
fs.mkdirSync(outputDir, { recursive: true });

const viewports = [
  { name: "desktop", width: 1440, height: 1000 },
  { name: "mobile", width: 390, height: 844 },
];
const consoleEvents = [];
const pageErrors = [];
const requests = [];
const responses = [];
const failedRequests = [];
const screenshots = [];
const steps = [];

function recordStep(viewport, name, status, detail = {}) {
  steps.push({ viewport, name, status, detail });
}

async function visibleText(page) {
  return (await page.locator("body").innerText()).replace(/\s+/g, " ").trim();
}

async function screenshot(page, viewport, name) {
  const file = path.join(outputDir, `${viewport}-${name}.png`);
  await page.screenshot({ path: file, fullPage: true });
  screenshots.push(path.basename(file));
}

async function firstVisible(locators) {
  for (const locator of locators) {
    const count = await locator.count();
    for (let index = 0; index < count; index += 1) {
      const item = locator.nth(index);
      if (await item.isVisible().catch(() => false)) return item;
    }
  }
  return null;
}

async function controlForText(page, pattern) {
  const semantic = await firstVisible([
    page.getByRole("button", { name: pattern }),
    page.getByRole("link", { name: pattern }),
  ]);
  if (semantic) return semantic;
  const text = await firstVisible([page.getByText(pattern)]);
  if (!text) return null;
  const ancestor = text.locator(
    "xpath=ancestor-or-self::*[self::button or self::a or self::article or self::tr or @role='button' or @role='link'][1]",
  );
  return await ancestor.count() && await ancestor.isVisible().catch(() => false) ? ancestor : null;
}

async function selectRun(select, namePattern, id) {
  const options = await select.locator("option").evaluateAll((nodes) =>
    nodes.map((node) => ({ value: node.value, label: node.textContent || "" })),
  );
  const choice = options.find((option) => namePattern.test(option.label) || option.value === id);
  if (!choice) return false;
  await select.selectOption(choice.value);
  return true;
}

async function run() {
  let chromium;
  try {
    ({ chromium } = require("playwright"));
  } catch (error) {
    throw new Error(`Playwright unavailable: ${error.message}`);
  }
  const browser = await chromium.launch({ headless: true, executablePath });
  try {
    for (const viewport of viewports) {
      const context = await browser.newContext({ viewport: { width: viewport.width, height: viewport.height } });
      const page = await context.newPage();
      page.on("console", (message) => consoleEvents.push({ viewport: viewport.name, type: message.type(), text: message.text() }));
      page.on("pageerror", (error) => pageErrors.push({ viewport: viewport.name, message: String(error) }));
      page.on("request", (request) => {
        if (request.url().startsWith(baseUrl)) {
          requests.push({ viewport: viewport.name, method: request.method(), url: request.url() });
        }
      });
      page.on("response", (response) => {
        if (response.url().startsWith(baseUrl)) {
          responses.push({
            viewport: viewport.name,
            method: response.request().method(),
            status: response.status(),
            url: response.url(),
          });
        }
      });
      page.on("requestfailed", (request) => {
        if (request.url().startsWith(baseUrl)) {
          failedRequests.push({
            viewport: viewport.name,
            method: request.method(),
            url: request.url(),
            error: request.failure()?.errorText || "unknown",
          });
        }
      });

      await page.goto(baseUrl, { waitUntil: "networkidle" });
      const initialText = await visibleText(page);
      recordStep(viewport.name, "initial-run-list", initialText.length > 0 ? "PASS" : "FAIL", {
        body_characters: initialText.length,
      });
      await screenshot(page, viewport.name, "run-list");

      // Creation must originate in a visible control. Network observation is
      // evidence of that action, never a replacement for it.
      const createName = `journey ${viewport.name}`;
      let createActions = 0;
      const postBefore = responses.filter((item) => item.viewport === viewport.name && item.method === "POST" && /\/api\/runs$/.test(item.url)).length;
      const createControl = await firstVisible([
        page.getByRole("button", { name: /new|create|launch|start.*run|run.*experiment/i }),
        page.getByRole("link", { name: /new|create|launch|start.*run|run.*experiment/i }),
      ]);
      if (createControl) {
        await createControl.click();
        createActions += 1;
        await page.waitForTimeout(100);
        const form = await firstVisible([
          page.locator("dialog"),
          page.locator("[role=dialog]"),
          page.locator("form"),
        ]);
        if (form) {
          const nameInput = await firstVisible([
            form.getByLabel(/run name|name/i),
            form.locator('input[name*="name" i], input[placeholder*="name" i]'),
          ]);
          if (nameInput) {
            await nameInput.fill(createName);
            createActions += 1;
          }
          const datasetSelect = await firstVisible([
            form.getByLabel(/dataset/i),
            form.locator('select[name*="dataset" i]'),
          ]);
          if (datasetSelect) {
            if (await datasetSelect.evaluate((node) => node.tagName === "SELECT")) {
              const options = await datasetSelect.locator("option").evaluateAll((nodes) => nodes.map((node) => node.value));
              const value = options.find((item) => item === "support-intents-v3") || options.find(Boolean);
              if (value) await datasetSelect.selectOption(value);
            } else {
              await datasetSelect.fill("support-intents-v3");
            }
            createActions += 1;
          }
          const submit = await firstVisible([
            form.getByRole("button", { name: /create|launch|start|submit|run/i }),
            form.locator('button[type="submit"], input[type="submit"]'),
          ]);
          if (submit) {
            await submit.click();
            createActions += 1;
          }
        }
      }
      await page.waitForTimeout(700);
      const createText = await visibleText(page);
      const postAfter = responses.filter((item) => item.viewport === viewport.name && item.method === "POST" && /\/api\/runs$/.test(item.url));
      const createResponse = postAfter.slice(postBefore).find((item) => item.status === 201);
      const createdInUi = createText.toLowerCase().includes(createName) || /queued/i.test(createText);
      recordStep(viewport.name, "create-run", createControl && createResponse && createdInUi ? "PASS" : "FAIL", {
        ui_control: Boolean(createControl),
        ui_actions: createActions,
        post_status: createResponse?.status || null,
        created_exposed_in_ui: createdInUi,
      });
      await screenshot(page, viewport.name, "created-run");

      const progressControl = await controlForText(page, /nightly ablation/i);
      if (progressControl) await progressControl.click();
      await page.waitForTimeout(300);
      const progressText = await visibleText(page);
      const progressObserved = /(?:63\s*%|progress[^0-9]{0,20}63|63[^0-9]{0,20}progress)/i.test(progressText);
      recordStep(viewport.name, "view-progress", progressControl && progressObserved ? "PASS" : "FAIL", {
        ui_control: Boolean(progressControl),
        exposed_in_ui: progressObserved,
      });
      await screenshot(page, viewport.name, "progress");

      const compareBefore = responses.filter((item) => item.viewport === viewport.name && item.method === "GET" && /\/api\/compare\?/.test(item.url)).length;
      let selectionActions = 0;
      const selects = page.locator("select:visible");
      if (await selects.count() >= 2) {
        if (await selectRun(selects.nth(0), /retrieval baseline/i, "run-201")) selectionActions += 1;
        if (await selectRun(selects.nth(1), /hybrid reranker/i, "run-202")) selectionActions += 1;
      } else {
        const leftChoice = await firstVisible([page.getByLabel(/retrieval baseline/i)]);
        const rightChoice = await firstVisible([page.getByLabel(/hybrid reranker/i)]);
        if (leftChoice) { await leftChoice.click(); selectionActions += 1; }
        if (rightChoice) { await rightChoice.click(); selectionActions += 1; }
      }
      const compareControl = await firstVisible([
        page.getByRole("button", { name: /compare/i }),
        page.getByRole("link", { name: /compare/i }),
      ]);
      if (compareControl) await compareControl.click();
      await page.waitForTimeout(500);
      const compareText = await visibleText(page);
      const compareAfter = responses.filter((item) => item.viewport === viewport.name && item.method === "GET" && /\/api\/compare\?/.test(item.url));
      const compareResponse = compareAfter.slice(compareBefore).find((item) => item.status === 200);
      const deltaObserved = /(?:4\.3|0\.043)/.test(compareText);
      recordStep(
        viewport.name,
        "compare-two-runs",
        selectionActions >= 2 && compareControl && compareResponse && deltaObserved ? "PASS" : "FAIL",
        {
          selection_actions: selectionActions,
          compare_control: Boolean(compareControl),
          get_status: compareResponse?.status || null,
          delta_exposed_in_ui: deltaObserved,
        },
      );
      await screenshot(page, viewport.name, "comparison");

      const logsBefore = responses.filter((item) => item.viewport === viewport.name && item.method === "GET" && /\/api\/runs\/run-204\/logs/.test(item.url)).length;
      const failureControl = await controlForText(page, /high-recall stress test/i);
      if (failureControl) await failureControl.click();
      await page.waitForTimeout(250);
      let failureText = await visibleText(page);
      let logsControl = null;
      let logsAfter = responses.filter((item) => item.viewport === viewport.name && item.method === "GET" && /\/api\/runs\/run-204\/logs/.test(item.url));
      if (logsAfter.length === logsBefore) {
        logsControl = await firstVisible([
          page.getByRole("button", { name: /logs|diagnos|inspect failure|view output/i }),
          page.getByRole("link", { name: /logs|diagnos|inspect failure|view output/i }),
        ]);
        if (logsControl) await logsControl.click();
        await page.waitForTimeout(500);
        failureText = await visibleText(page);
        logsAfter = responses.filter((item) => item.viewport === viewport.name && item.method === "GET" && /\/api\/runs\/run-204\/logs/.test(item.url));
      }
      const logsResponse = logsAfter.slice(logsBefore).find((item) => item.status === 200);
      const failureObserved = /embedding_dimension_mismatch|Expected 1536/i.test(failureText);
      const repeatedLogs = (failureText.match(/evaluator item/gi) || []).length;
      const longLogsObserved = repeatedLogs >= 5 || /(?:9[0-9]|1[0-9]{2})\s+(?:log )?lines/i.test(failureText);
      recordStep(
        viewport.name,
        "diagnose-failure",
        failureControl && logsResponse && failureObserved && longLogsObserved ? "PASS" : "FAIL",
        {
          run_control: Boolean(failureControl),
          logs_control: Boolean(logsControl),
          logs_status: logsResponse?.status || null,
          failure_exposed_in_ui: failureObserved,
          long_logs_exposed_in_ui: longLogsObserved,
          visible_repeated_log_lines: repeatedLogs,
        },
      );
      await screenshot(page, viewport.name, "failure-diagnosis");

      await page.route(/\/api\/runs(?:\?.*)?$/, async (route) => {
        await new Promise((resolve) => setTimeout(resolve, 700));
        await route.continue();
      });
      const loadingNavigation = page.reload({ waitUntil: "domcontentloaded" });
      await page.waitForTimeout(150);
      const loadingObserved = /loading|fetching|preparing|skeleton/i.test(await visibleText(page));
      await loadingNavigation;
      await page.unroute(/\/api\/runs(?:\?.*)?$/);
      recordStep(viewport.name, "loading-state", loadingObserved ? "PASS" : "FAIL", { exposed_in_ui: loadingObserved });

      await page.route(/\/api\/runs(?:\?.*)?$/, async (route) => {
        await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ runs: [] }) });
      });
      await page.reload({ waitUntil: "networkidle" }).catch(() => {});
      const emptyText = await visibleText(page);
      const emptyObserved = /no runs|no experiments|empty|create.*first|start.*run/i.test(emptyText);
      recordStep(viewport.name, "empty-state", emptyObserved ? "PASS" : "FAIL", { exposed_in_ui: emptyObserved });
      await screenshot(page, viewport.name, "empty-state");
      await page.unroute(/\/api\/runs(?:\?.*)?$/);

      await page.route(/\/api\/runs(?:\?.*)?$/, async (route) => {
        await route.fulfill({
          status: 500,
          contentType: "application/json",
          body: JSON.stringify({ error: { code: "fixture_failure", message: "Planted 500 scenario" } }),
        });
      });
      await page.reload({ waitUntil: "networkidle" }).catch(() => {});
      const errorText = await visibleText(page);
      const errorObserved = /error|failed|try again|retry|unavailable|could not/i.test(errorText);
      recordStep(viewport.name, "error-state", errorObserved ? "PASS" : "FAIL", { exposed_in_ui: errorObserved });
      await screenshot(page, viewport.name, "error-state");
      await page.unroute(/\/api\/runs(?:\?.*)?$/);

      const layout = await page.evaluate(() => ({
        scrollWidth: document.documentElement.scrollWidth,
        clientWidth: document.documentElement.clientWidth,
      }));
      recordStep(viewport.name, "viewport-fit", layout.scrollWidth <= layout.clientWidth + 1 ? "PASS" : "FAIL", layout);
      await context.close();
    }
  } finally {
    await browser.close();
  }

  const report = {
    version: "product-journey-v2",
    status: steps.every((step) => step.status === "PASS") && pageErrors.length === 0 && failedRequests.length === 0 ? "PASS" : "FAIL",
    base_url: baseUrl,
    viewports,
    steps,
    screenshots,
    console_events: consoleEvents,
    page_errors: pageErrors,
    requests,
    responses,
    failed_requests: failedRequests,
  };
  fs.writeFileSync(path.join(outputDir, "browser-report.json"), `${JSON.stringify(report, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, "console.json"), `${JSON.stringify({ console_events: consoleEvents, page_errors: pageErrors }, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, "requests.json"), `${JSON.stringify({ requests, responses, failed_requests: failedRequests }, null, 2)}\n`);
  process.stdout.write(`${JSON.stringify(report)}\n`);
  process.exitCode = report.status === "PASS" ? 0 : 1;
}

run().catch((error) => {
  const report = { version: "product-journey-v2", status: "INVALID", error: String(error?.stack || error) };
  fs.writeFileSync(path.join(outputDir, "browser-report.json"), `${JSON.stringify(report, null, 2)}\n`);
  process.stdout.write(`${JSON.stringify(report)}\n`);
  process.exitCode = 2;
});
