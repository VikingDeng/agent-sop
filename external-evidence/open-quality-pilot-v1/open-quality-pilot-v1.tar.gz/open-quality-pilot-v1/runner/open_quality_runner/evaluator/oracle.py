"""Run evaluator-owned fixture oracles without exposing their paths to Agents."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from .io import EvaluationError, expect_mapping, read_json


def _last_json(stdout: str) -> dict[str, Any]:
    for line in reversed(stdout.splitlines()):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    raise EvaluationError("Oracle emitted no JSON object")


def run_oracle(
    fixture_root: Path,
    candidate_root: Path,
    submission: Path | None = None,
    pristine_root: Path | None = None,
    timeout_seconds: int = 60,
) -> dict[str, Any]:
    fixture_root = fixture_root.resolve(strict=True)
    candidate_root = candidate_root.resolve(strict=True)
    manifest = expect_mapping(read_json(fixture_root / "fixture.json"), "fixture manifest")
    fixture_id = manifest.get("outcome_id")
    if not isinstance(fixture_id, str) or not fixture_id:
        raise EvaluationError("fixture manifest has no outcome_id")
    oracle_relative = manifest.get("independent_oracle")
    if not isinstance(oracle_relative, str) or not oracle_relative:
        raise EvaluationError("fixture manifest has no independent_oracle")
    oracle_path = (fixture_root / oracle_relative).resolve(strict=True)
    try:
        oracle_path.relative_to(fixture_root)
    except ValueError as error:
        raise EvaluationError("independent Oracle escapes fixture root") from error
    commands: dict[str, list[str]] = {
        "out_product_02": [sys.executable, str(oracle_path), str(candidate_root)],
        "out_idea_01": [
            sys.executable,
            str(oracle_path),
            str(candidate_root),
            str(submission or candidate_root / "submission.json"),
        ],
        "out_research_02": [
            sys.executable,
            str(oracle_path),
            str(candidate_root),
            "--submission",
            str(submission or candidate_root / "submission.json"),
        ],
        "out_simple_02": [
            sys.executable,
            str(oracle_path),
            str(candidate_root),
            "--baseline",
            str(pristine_root or fixture_root / "workspace"),
        ],
    }
    if fixture_id not in commands:
        raise EvaluationError(f"unsupported outcome fixture: {fixture_id}")
    environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        process = subprocess.run(
            commands[fixture_id],
            cwd=fixture_root,
            env=environment,
            text=True,
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        raise EvaluationError(f"Oracle execution failed: {error}") from error
    report = _last_json(process.stdout)
    return {
        "fixture": fixture_id,
        "status": "PASS" if process.returncode == 0 and report.get("status") == "PASS" else "FAIL",
        "exit_code": process.returncode,
        "report": report,
        "stdout_tail": process.stdout[-2000:],
        "stderr_tail": process.stderr[-2000:],
    }
