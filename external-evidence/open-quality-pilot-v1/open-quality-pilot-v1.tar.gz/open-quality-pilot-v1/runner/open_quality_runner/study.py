"""Freeze reproducible Pilot inputs without running any Agent sample.

The generated directory is evaluator-side state.  It contains prompts,
materialized ZIPs, treatment receipts, and a deterministic assignment plan.
It deliberately does not claim that a run happened.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import random
import shutil
import subprocess
from typing import Any

from .core import RunnerError, canonical_tree_sha256, sha256_file


BASELINE_COMMIT = "497b5ba436a1a0392af01db3f2fecd3aa53e95e9"
CANDIDATE_COMMIT = "10dafa87d2b4d20b265ef260e73afdf7799d6548"
PILOT_MODEL = "gpt-5.6-sol"
PILOT_EFFORT = "high"
PILOT_ARMS = ("A", "B", "C")


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n"
    path.write_text(text, encoding="utf-8")


def _git(checkout: Path, *arguments: str) -> bytes:
    process = subprocess.run(
        ["git", "-C", str(checkout), *arguments],
        capture_output=True,
        check=False,
    )
    if process.returncode != 0:
        raise RunnerError(process.stderr.decode("utf-8", "replace"))
    return process.stdout


def _commit_tree(checkout: Path, revision: str) -> str:
    return _git(checkout, "rev-parse", f"{revision}^{{tree}}").decode().strip()


def _git_archive(checkout: Path, revision: str, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as handle:
        process = subprocess.run(
            ["git", "-C", str(checkout), "archive", "--format=tar", revision],
            stdout=handle,
            stderr=subprocess.PIPE,
            check=False,
        )
    if process.returncode != 0:
        raise RunnerError(process.stderr.decode("utf-8", "replace"))


def _arm_order(seed: str, fixture_id: str, replicate: int) -> list[str]:
    digest = hashlib.sha256(f"{seed}\0{fixture_id}\0{replicate}".encode()).digest()
    generator = random.Random(int.from_bytes(digest, "big"))
    order = list(PILOT_ARMS)
    generator.shuffle(order)
    return order


def _routing_prompt(case: dict[str, Any]) -> str:
    labels = """Return only one JSON object with this closed shape:
{"fixture_id":"...","primary_mode":"fast_path|option_search|contract_ready_execution|evidence_closure|re_contract","overlays":[...],"user_decision":"not_needed|defer_until_evidence|required_now"}

Meanings:
- fast_path: bounded scope and direct Oracle; act and run the nearest check.
- option_search: a material direction is unresolved; compare distinct choices and discriminating evidence.
- contract_ready_execution: direction and acceptance are frozen; implement faithfully.
- evidence_closure: the artifact exists; the remaining work is real walkthrough, Oracle, review, and verdict.
- re_contract: method, claim, benchmark, public behavior, authority, or material budget changed; stop for a HUMAN decision.

Allowed overlays: browser_walkthrough, durable_goal, high_risk_supervision, independent_review, research_collision, research_fidelity, visual_critic.
Use overlays only when the prompt provides a concrete need. Do not explain the JSON."""
    return f"{labels}\n\nfixture_id: {case['id']}\nTask:\n{case['prompt']}\n"


def _outcome_prompt(fixture: dict[str, Any]) -> str:
    return (
        f"{fixture['prompt']}\n\n"
        "The current directory is the complete authorized task workspace. "
        "Follow its README and frozen contracts. Do not search for or infer evaluator assets, "
        "other arms, or hidden answers. Work until the requested deliverable is complete, then "
        "report what changed and the checks you actually ran.\n"
    )


def freeze_pilot(
    checkout: Path,
    output: Path,
    *,
    seed: str,
    model: str = PILOT_MODEL,
    effort: str = PILOT_EFFORT,
) -> dict[str, Any]:
    checkout = checkout.resolve(strict=True)
    output = output.resolve()
    if output.exists() and any(output.iterdir()):
        raise RunnerError(f"freeze output must be empty: {output}")
    output.mkdir(parents=True, exist_ok=True)
    evaluation = checkout / "evaluations" / "open-quality-v1"
    routing = json.loads((evaluation / "routing-cases.json").read_text(encoding="utf-8"))
    outcomes = json.loads((evaluation / "outcome-fixtures.json").read_text(encoding="utf-8"))
    routing_cases = [case for case in routing["cases"] if case.get("pilot") is True]
    outcome_cases = [case for case in outcomes["fixtures"] if case.get("pilot") is True]
    if len(routing_cases) != 12 or len(outcome_cases) != 4:
        raise RunnerError("frozen Pilot must contain exactly 12 routing and 4 outcome fixtures")

    prompts = output / "prompts"
    for case in routing_cases:
        (prompts / "routing").mkdir(parents=True, exist_ok=True)
        (prompts / "routing" / f"{case['id']}.txt").write_text(_routing_prompt(case), encoding="utf-8")
    for fixture in outcome_cases:
        (prompts / "outcome").mkdir(parents=True, exist_ok=True)
        (prompts / "outcome" / f"{fixture['id']}.txt").write_text(_outcome_prompt(fixture), encoding="utf-8")

    inputs = output / "inputs"
    materializer = evaluation / "fixtures" / "materialize_fixture.py"
    input_receipts: list[dict[str, Any]] = []
    for fixture in outcome_cases:
        bundle = inputs / f"{fixture['id']}.zip"
        process = subprocess.run(
            ["python3", str(materializer), fixture["id"], str(bundle)],
            cwd=checkout,
            text=True,
            capture_output=True,
            check=False,
        )
        if process.returncode != 0:
            raise RunnerError(process.stderr or process.stdout)
        receipt = json.loads(process.stdout)
        if receipt["archive_sha256"] != sha256_file(bundle):
            raise RunnerError(f"materializer receipt drifted for {fixture['id']}")
        input_receipts.append(receipt)

    treatments = output / "treatments"
    treatments.mkdir()
    raw_receipt = treatments / "A.json"
    _write_json(raw_receipt, {"arm": "A", "treatment": "raw_platform_only", "repository_commit": None})
    for arm, revision in (("B", BASELINE_COMMIT), ("C", CANDIDATE_COMMIT)):
        archive = treatments / f"{arm}.tar"
        _git_archive(checkout, revision, archive)
        _write_json(
            treatments / f"{arm}.json",
            {
                "arm": arm,
                "revision": revision,
                "git_tree": _commit_tree(checkout, revision),
                "canonical_tree_sha256": canonical_tree_sha256(checkout, revision),
                "archive_sha256": sha256_file(archive),
                "archive_ref": archive.name,
            },
        )

    assignment_slots: list[dict[str, Any]] = []
    for fixture in sorted(outcome_cases, key=lambda value: value["id"]):
        order = _arm_order(seed, fixture["id"], 1)
        assignment_slots.append(
            {
                "fixture_id": fixture["id"],
                "replicate": 1,
                "concealed_assignments": {
                    arm: f"blind-{index + 1}-{hashlib.sha256(f'{seed}:{fixture['id']}:{arm}'.encode()).hexdigest()[:12]}"
                    for index, arm in enumerate(order)
                },
            }
        )
    assignment = {
        "schema_version": "open-quality-assignment-plan-v1",
        "stage": "pilot",
        "seed_commitment_sha256": hashlib.sha256(seed.encode()).hexdigest(),
        "outcome_slots": assignment_slots,
    }
    _write_json(output / "assignment-plan.json", assignment)

    permissions = {
        "version": "open-quality-permissions-v1",
        "model": model,
        "reasoning_effort": effort,
        "approval_policy": "never",
        "web_search": "disabled",
        "external_agent_network": "disabled except product loopback fixture",
        "formal_isolation": "must pass open_quality_runner readiness before any sample",
    }
    _write_json(output / "permissions.json", permissions)
    freeze = {
        "version": "open-quality-pilot-freeze-v1",
        "status": "FROZEN_NOT_RUN",
        "formal_samples_exist": False,
        "candidate_commit": CANDIDATE_COMMIT,
        "candidate_git_tree": _commit_tree(checkout, CANDIDATE_COMMIT),
        "candidate_tree_sha256_algorithm": "sha256(git ls-tree -r -z --full-tree REV)",
        "candidate_tree_sha256": canonical_tree_sha256(checkout, CANDIDATE_COMMIT),
        "baseline_commit": BASELINE_COMMIT,
        "model": model,
        "reasoning_effort": effort,
        "routing_cases": [case["id"] for case in routing_cases],
        "outcome_fixtures": [fixture["id"] for fixture in outcome_cases],
        "input_receipts": input_receipts,
        "assignment_plan_sha256": sha256_file(output / "assignment-plan.json"),
        "permissions_sha256": sha256_file(output / "permissions.json"),
    }
    _write_json(output / "freeze.json", freeze)
    return freeze
