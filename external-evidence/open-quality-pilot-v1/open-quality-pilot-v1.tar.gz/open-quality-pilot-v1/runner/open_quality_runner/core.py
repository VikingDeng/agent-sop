"""Small trusted-runner primitives.

This module deliberately does not contain an override that turns a failed
isolation probe into a formal run.  A Pilot slot is useful only if the model
cannot read evaluator assets, other arms, or earlier outputs.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tempfile
from typing import Any


MODEL_WEIGHTS = {"sol": 25, "terra": 10, "luna": 1}
FORMAL_ISOLATION_REQUIREMENTS = (
    "filesystem_namespace_or_vm",
    "pid_namespace_or_slot_uid",
    "tool_network_default_deny",
    "credential_broker_or_two_phase_handoff",
    "tool_child_fd_scrub",
)


class RunnerError(RuntimeError):
    """A fail-closed runner precondition or evidence error."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_tree_sha256(checkout: Path, revision: str) -> str:
    """Hash the exact NUL-delimited Git tree listing frozen by this study."""
    process = subprocess.run(
        ["git", "-C", str(checkout), "ls-tree", "-r", "-z", "--full-tree", revision],
        capture_output=True,
        check=False,
    )
    if process.returncode != 0:
        raise RunnerError(process.stderr.decode("utf-8", "replace"))
    return hashlib.sha256(process.stdout).hexdigest()


def _bubblewrap() -> str | None:
    return shutil.which("bwrap")


def isolation_preflight() -> dict[str, Any]:
    """Prove that a new mount namespace can hide a planted evaluator secret."""
    binary = _bubblewrap()
    if binary is None:
        return {"status": "NO_GO", "backend": None, "reason": "bwrap unavailable"}
    with tempfile.TemporaryDirectory(prefix="oq-isolation-") as temporary:
        root = Path(temporary)
        visible = root / "visible"
        hidden = root / "hidden"
        visible.mkdir()
        hidden.mkdir()
        (visible / "public.txt").write_text("public\n", encoding="utf-8")
        (hidden / "oracle-secret.txt").write_text("must-not-be-visible\n", encoding="utf-8")
        command = [
            binary, "--die-with-parent", "--unshare-user", "--uid", "0", "--gid", "0",
            "--unshare-pid", "--unshare-ipc", "--unshare-uts", "--unshare-net",
            "--ro-bind", "/usr", "/usr", "--ro-bind", "/bin", "/bin",
            "--ro-bind", "/lib", "/lib", "--proc", "/proc", "--dev", "/dev",
            "--ro-bind", str(visible), "/workspace", "--chdir", "/workspace",
            "/bin/sh", "-c", "test -f public.txt && test ! -e /oracle-secret.txt",
        ]
        if Path("/lib64").exists():
            insertion = command.index("--proc")
            command[insertion:insertion] = ["--ro-bind", "/lib64", "/lib64"]
        try:
            process = subprocess.run(
                command, text=True, capture_output=True, check=False, timeout=3
            )
        except subprocess.TimeoutExpired as error:
            return {
                "status": "NO_GO",
                "backend": "bubblewrap",
                "exit_code": None,
                "reason": f"namespace probe timed out: {error}",
            }
        return {
            "status": "PASS" if process.returncode == 0 else "NO_GO",
            "backend": "bubblewrap",
            "exit_code": process.returncode,
            "reason": None if process.returncode == 0 else (process.stderr.strip() or "namespace probe failed"),
        }


def readiness_report() -> dict[str, Any]:
    """Return an honest formal-run readiness receipt.

    A copy-only chroot is intentionally not accepted here.  It can hide paths,
    but without a PID namespace or slot UID it can still signal same-UID host
    processes and reach host loopback.  Authentication also needs a trusted
    handoff before any agent-controlled tool process exists.
    """

    filesystem = isolation_preflight()
    checks = {
        "filesystem_namespace_or_vm": filesystem["status"] == "PASS",
        "pid_namespace_or_slot_uid": False,
        "tool_network_default_deny": False,
        "credential_broker_or_two_phase_handoff": False,
        "tool_child_fd_scrub": False,
    }
    missing = [name for name in FORMAL_ISOLATION_REQUIREMENTS if not checks[name]]
    return {
        "version": "open-quality-runner-readiness-v1",
        "status": "GO" if not missing else "NO_GO",
        "formal_samples_permitted": not missing,
        "platform": platform.platform(),
        "checks": checks,
        "filesystem_probe": filesystem,
        "missing_requirements": missing,
        "next_action": (
            "run frozen pilot slots"
            if not missing
            else "move execution to one isolated container or VM per slot with an external collector"
        ),
    }


def assert_formal_isolation() -> dict[str, Any]:
    report = isolation_preflight()
    if report["status"] != "PASS":
        raise RunnerError(f"formal Pilot isolation unavailable: {report['reason']}")
    return report


def _family(model: str) -> str:
    lowered = model.lower()
    for family in MODEL_WEIGHTS:
        if family in lowered:
            return family
    return "unknown"


def collect_wcu(audit: dict[str, Any]) -> dict[str, Any]:
    """Recompute WCU including separately reported system/guardian overhead."""
    if audit.get("cost_status") != "complete":
        raise RunnerError("session audit cost attribution is incomplete")
    total = 0
    unknown: list[str] = []
    components: dict[str, int] = {}
    for label, models in (
        ("agent", audit.get("model_totals", {})),
        ("system", audit.get("system_overhead_model_totals", {})),
    ):
        if not isinstance(models, dict):
            raise RunnerError(f"{label} model totals are malformed")
        for model, usage in models.items():
            family = _family(str(model))
            tokens = usage.get("total_tokens") if isinstance(usage, dict) else None
            if isinstance(tokens, bool) or not isinstance(tokens, int) or tokens < 0:
                raise RunnerError(f"invalid token count for {model}")
            if family == "unknown":
                unknown.append(str(model))
                continue
            weighted = MODEL_WEIGHTS[family] * tokens
            components[f"{label}:{model}"] = weighted
            total += weighted
    if unknown:
        raise RunnerError(f"unknown model families: {unknown}")
    return {"reported_wcu_complete": True, "reported_wcu": total, "components": components}


def safe_environment(run_home: Path) -> dict[str, str]:
    """Return the intentionally tiny environment supplied to Codex."""
    environment = {
        "HOME": str(run_home),
        "CODEX_HOME": str(run_home / ".codex"),
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": "C.UTF-8",
    }
    # Authentication stays inherited in process memory when present; it is
    # never copied into an artifact, command receipt, or returned mapping.
    for name in ("CODEX_ACCESS_TOKEN", "CODEX_API_KEY"):
        if name in os.environ:
            environment[name] = os.environ[name]
    return environment


def public_environment_receipt(environment: dict[str, str]) -> dict[str, str]:
    return {key: value for key, value in environment.items() if key not in {"CODEX_ACCESS_TOKEN", "CODEX_API_KEY"}}


def read_thread_id(events_path: Path) -> str:
    for raw in events_path.read_text(encoding="utf-8").splitlines():
        try:
            event = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if event.get("type") == "thread.started" and isinstance(event.get("thread_id"), str):
            return event["thread_id"]
    raise RunnerError("exec event stream has no thread.started id")
