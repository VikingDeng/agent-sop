from __future__ import annotations

import contextlib
import io
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from open_quality_runner.evaluator import EvaluationError, evaluate_run, normalize_blind_bundle
from open_quality_runner.evaluator.browser import run_product_browser
from open_quality_runner.evaluator.cli import main
from open_quality_runner.evaluator.oracle import run_oracle
from open_quality_runner.evaluator.schema import validate, validate_files


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT.parent / "agent-sop" / "evaluations" / "open-quality-v1" / "fixtures"


def _research_submission() -> dict[str, object]:
    return {
        "verdict": "NO-GO",
        "recomputed_metrics": {
            "baseline_success": 0.5,
            "method_success": 0.5,
            "success_delta": 0.0,
            "tool_cost_ratio": 1.0,
        },
        "blockers": [],
        "claim_status": {
            "scientific_success": False,
            "smoke_is_paper_evidence": False,
            "reason": "The frozen evidence is not eligible for a success claim.",
        },
        "fresh_run_plan": "Run a new preregistered interleaved experiment with complete provenance.",
    }


def _playwright_ready() -> bool:
    if shutil.which("node") is None:
        return False
    probe = """
const {chromium}=require('playwright');
chromium.launch({headless:true}).then(async b=>{await b.close()}).catch(()=>process.exit(1));
"""
    try:
        return subprocess.run(
            ["node", "-e", probe],
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
            check=False,
        ).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


class SchemaTests(unittest.TestCase):
    def test_validates_complete_frozen_research_schema(self) -> None:
        if not FIXTURES.exists():
            self.skipTest("external fixture checkout is unavailable")
        schema_path = FIXTURES / "out_research_02" / "workspace" / "submission.schema.json"
        with tempfile.TemporaryDirectory() as temporary:
            submission = Path(temporary) / "submission.json"
            submission.write_text(json.dumps(_research_submission()), encoding="utf-8")
            self.assertEqual(validate_files(submission, schema_path)["status"], "PASS")
            value = _research_submission()
            value["unexpected"] = True
            submission.write_text(json.dumps(value), encoding="utf-8")
            report = validate_files(submission, schema_path)
            self.assertEqual(report["status"], "FAIL")
            self.assertIn("unexpected property", "\n".join(report["errors"]))

    def test_every_frozen_schema_keyword_is_supported(self) -> None:
        if not FIXTURES.exists():
            self.skipTest("external fixture checkout is unavailable")
        with tempfile.TemporaryDirectory() as temporary:
            instance = Path(temporary) / "submission.json"
            instance.write_text("{}", encoding="utf-8")
            for fixture_id in ("out_idea_01", "out_research_02"):
                with self.subTest(fixture=fixture_id):
                    schema = FIXTURES / fixture_id / "workspace" / "submission.schema.json"
                    self.assertEqual(validate_files(instance, schema)["status"], "FAIL")

    def test_schema_checks_nested_constraints_and_json_types(self) -> None:
        schema = {
            "type": "object",
            "required": ["items"],
            "additionalProperties": False,
            "properties": {
                "items": {
                    "type": "array",
                    "minItems": 2,
                    "items": {"type": "integer", "minimum": 1},
                }
            },
        }
        errors = validate({"items": [True, 0], "extra": 1}, schema)
        self.assertTrue(any("expected type" in error for error in errors))
        self.assertTrue(any("below minimum" in error for error in errors))
        self.assertTrue(any("unexpected property" in error for error in errors))

    def test_unknown_or_malformed_schema_fails_closed(self) -> None:
        with self.assertRaises(EvaluationError):
            validate("x", {"type": "string", "format": "email"})
        with self.assertRaises(EvaluationError):
            validate("x", {"type": "string", "pattern": "["})
        with self.assertRaises(EvaluationError):
            validate([], {"type": "array", "minItems": True})
        self.assertTrue(validate(True, {"enum": [1]}))
        self.assertTrue(validate(float("nan"), {"type": "number"}))

    def test_json_reader_rejects_non_json_numbers_and_duplicate_keys(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            instance = Path(temporary) / "instance.json"
            schema = Path(temporary) / "schema.json"
            schema.write_text('{"type":"object"}', encoding="utf-8")
            instance.write_text('{"value":NaN}', encoding="utf-8")
            with self.assertRaises(EvaluationError):
                validate_files(instance, schema)
            instance.write_text('{"value":1,"value":2}', encoding="utf-8")
            with self.assertRaises(EvaluationError):
                validate_files(instance, schema)


class OracleAndApiTests(unittest.TestCase):
    def test_external_manifest_oracle_is_executed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            fixture = root / "external-fixture"
            candidate = root / "candidate"
            (fixture / "oracle").mkdir(parents=True)
            candidate.mkdir()
            (candidate / "submission.json").write_text("{}", encoding="utf-8")
            (fixture / "fixture.json").write_text(
                json.dumps({"outcome_id": "out_idea_01", "independent_oracle": "oracle/check.py"}),
                encoding="utf-8",
            )
            (fixture / "oracle" / "check.py").write_text(
                "import json\nprint(json.dumps({'status':'PASS','source':'external'}))\n",
                encoding="utf-8",
            )
            report = run_oracle(fixture, candidate)
            self.assertEqual(report["status"], "PASS")
            self.assertEqual(report["report"]["source"], "external")

    def test_evaluate_requires_schema_and_oracle_to_pass(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            fixture = root / "fixture"
            candidate = root / "candidate"
            (fixture / "workspace").mkdir(parents=True)
            candidate.mkdir()
            (fixture / "fixture.json").write_text(
                json.dumps({"outcome_id": "out_research_02", "independent_oracle": "oracle/check.py"}),
                encoding="utf-8",
            )
            (fixture / "workspace" / "submission.schema.json").write_text(
                json.dumps({"type": "object", "required": ["verdict"], "properties": {"verdict": {"enum": ["NO-GO"]}}}),
                encoding="utf-8",
            )
            (candidate / "submission.json").write_text(json.dumps({"verdict": "NO-GO"}), encoding="utf-8")
            with mock.patch("open_quality_runner.evaluator.api.run_oracle", return_value={"status": "FAIL"}):
                report = evaluate_run(fixture, candidate)
            self.assertEqual(report["status"], "FAIL")
            self.assertEqual(report["checks"]["json_schema"]["status"], "PASS")

    def test_blind_normalization_is_detached_and_recursive(self) -> None:
        source = {"status": "PASS", "arm": "A", "nested": {"model": "secret", "steps": [1]}}
        normalized = normalize_blind_bundle(source)
        self.assertNotIn("arm", normalized)
        self.assertNotIn("model", normalized["nested"])
        normalized["nested"]["steps"].append(2)
        self.assertEqual(source["nested"]["steps"], [1])

    def test_cli_emits_structured_invalid_json(self) -> None:
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = main(["schema", Path("missing.json").as_posix(), Path("missing-schema.json").as_posix()])
        report = json.loads(output.getvalue())
        self.assertEqual(code, 2)
        self.assertEqual(report["status"], "INVALID")


class BrowserBoundaryTests(unittest.TestCase):
    def test_journey_contains_no_direct_request_client(self) -> None:
        source = (ROOT / "open_quality_runner" / "evaluator" / "product_journey.mjs").read_text(encoding="utf-8")
        self.assertNotIn("context.request", source)
        self.assertNotIn("async function api", source)
        self.assertIn("getByRole", source)
        self.assertIn("page.route", source)
        self.assertIn('width: 390', source)

    def test_missing_browser_runtime_is_not_skipped_by_evaluator(self) -> None:
        if not (FIXTURES / "out_product_02").exists():
            self.skipTest("external product fixture checkout is unavailable")
        candidate = FIXTURES / "out_product_02" / "workspace"
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(EvaluationError):
                run_product_browser(candidate, Path(temporary), node_command="definitely-not-a-node-command")

    def test_unavailable_playwright_browser_is_structured_invalid(self) -> None:
        if _playwright_ready():
            self.skipTest("Playwright browser is available")
        if not (FIXTURES / "out_product_02").exists():
            self.skipTest("external product fixture checkout is unavailable")
        candidate = FIXTURES / "out_product_02" / "workspace"
        with tempfile.TemporaryDirectory() as temporary:
            report = run_product_browser(candidate, Path(temporary))
        self.assertEqual(report["status"], "INVALID")
        self.assertEqual(report["report"]["status"], "INVALID")

    @unittest.skipUnless(_playwright_ready(), "Playwright browser binary is unavailable; unit fail-closed coverage still runs")
    def test_cheap_product_start_is_negative_browser_control(self) -> None:
        fixture = FIXTURES / "out_product_02"
        if not fixture.exists():
            self.skipTest("external product fixture checkout is unavailable")
        with tempfile.TemporaryDirectory() as temporary:
            candidate = Path(temporary) / "candidate"
            evidence = Path(temporary) / "evidence"
            shutil.copytree(fixture / "workspace", candidate)
            oracle = run_oracle(fixture, candidate)
            browser = run_product_browser(candidate, evidence)
        self.assertEqual(oracle["status"], "PASS")
        self.assertEqual(browser["status"], "FAIL")
        failed = {
            step["name"]
            for step in browser["report"]["steps"]
            if step["status"] == "FAIL"
        }
        self.assertTrue({"create-run", "compare-two-runs", "diagnose-failure"} & failed)


if __name__ == "__main__":
    unittest.main()
