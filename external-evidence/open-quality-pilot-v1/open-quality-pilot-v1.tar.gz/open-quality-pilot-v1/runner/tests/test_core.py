from __future__ import annotations

import os
from pathlib import Path
import unittest
from unittest import mock

from open_quality_runner.core import (
    RunnerError,
    collect_wcu,
    public_environment_receipt,
    readiness_report,
    safe_environment,
)


class CoreTests(unittest.TestCase):
    def test_wcu_includes_system_overhead(self) -> None:
        report = collect_wcu({
            "cost_status": "complete",
            "model_totals": {"gpt-5.6-terra": {"total_tokens": 100}},
            "system_overhead_model_totals": {"gpt-5.6-luna": {"total_tokens": 50}},
        })
        self.assertEqual(report["reported_wcu"], 1050)

    def test_uncertain_or_unknown_cost_fails_closed(self) -> None:
        with self.assertRaises(RunnerError):
            collect_wcu({"cost_status": "partial_uncertain", "model_totals": {}})
        with self.assertRaises(RunnerError):
            collect_wcu({"cost_status": "complete", "model_totals": {"mystery": {"total_tokens": 1}}})

    def test_auth_never_enters_public_receipt(self) -> None:
        with mock.patch.dict(os.environ, {"CODEX_ACCESS_TOKEN": "secret", "CODEX_API_KEY": "also-secret"}, clear=False):
            environment = safe_environment(Path("/run/user"))
            receipt = public_environment_receipt(environment)
        self.assertNotIn("CODEX_ACCESS_TOKEN", receipt)
        self.assertNotIn("CODEX_API_KEY", receipt)
        self.assertNotIn("secret", repr(receipt))

    def test_readiness_does_not_treat_chroot_as_formal_isolation(self) -> None:
        with mock.patch(
            "open_quality_runner.core.isolation_preflight",
            return_value={"status": "PASS", "backend": "bubblewrap", "reason": None},
        ):
            report = readiness_report()
        self.assertEqual(report["status"], "NO_GO")
        self.assertFalse(report["formal_samples_permitted"])
        self.assertIn("pid_namespace_or_slot_uid", report["missing_requirements"])
        self.assertIn("credential_broker_or_two_phase_handoff", report["missing_requirements"])


if __name__ == "__main__":
    unittest.main()
