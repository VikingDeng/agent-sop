from __future__ import annotations

import json
import tempfile
from pathlib import Path
import unittest

from open_quality_runner.core import RunnerError
from open_quality_runner.study import _arm_order, _routing_prompt, freeze_pilot


ROOT = Path(__file__).resolve().parents[1]
CHECKOUT = ROOT.parent / "agent-sop"


class StudyFreezeTests(unittest.TestCase):
    def test_assignment_order_is_deterministic_and_balanced(self) -> None:
        first = _arm_order("seed", "out_product_02", 1)
        second = _arm_order("seed", "out_product_02", 1)
        self.assertEqual(first, second)
        self.assertEqual(sorted(first), ["A", "B", "C"])

    def test_routing_prompt_defines_neutral_closed_taxonomy(self) -> None:
        prompt = _routing_prompt({"id": "case", "prompt": "bounded task"})
        self.assertIn('"primary_mode"', prompt)
        self.assertIn("fast_path", prompt)
        self.assertIn("re_contract", prompt)
        self.assertIn("Return only one JSON object", prompt)

    @unittest.skipUnless((CHECKOUT / ".git").exists(), "candidate checkout is unavailable")
    def test_freeze_materializes_exact_pilot_without_running_samples(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "frozen"
            report = freeze_pilot(CHECKOUT, output, seed="test-seed")
            self.assertEqual(report["status"], "FROZEN_NOT_RUN")
            self.assertFalse(report["formal_samples_exist"])
            self.assertEqual(len(report["routing_cases"]), 12)
            self.assertEqual(len(report["outcome_fixtures"]), 4)
            assignment = json.loads((output / "assignment-plan.json").read_text())
            self.assertEqual(len(assignment["outcome_slots"]), 4)
            self.assertEqual(
                sorted(assignment["outcome_slots"][0]["concealed_assignments"]),
                ["A", "B", "C"],
            )
            self.assertTrue((output / "inputs" / "out_simple_02.zip").is_file())
            self.assertTrue((output / "treatments" / "C.tar").is_file())

    @unittest.skipUnless((CHECKOUT / ".git").exists(), "candidate checkout is unavailable")
    def test_freeze_refuses_nonempty_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "frozen"
            output.mkdir()
            (output / "prior.txt").write_text("prior", encoding="utf-8")
            with self.assertRaises(RunnerError):
                freeze_pilot(CHECKOUT, output, seed="test-seed")


if __name__ == "__main__":
    unittest.main()
