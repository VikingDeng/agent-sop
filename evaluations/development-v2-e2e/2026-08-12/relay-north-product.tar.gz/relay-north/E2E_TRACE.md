# Relay North E2E trace

## Observable contract

- Complete local, single-user cold-chain incident coordination product for a regional clinic coordinator.
- Browser manifest with multiple shipments, selection/detail workflow, route and temperature context, and an append-only audit timeline.
- HTTP JSON API backed by SQLite; persisted state must remain after a real server stop/start.
- One incident per shipment with only `none -> open -> acknowledged -> resolved`; resolution requires a valid disposition. Invalid input and illegal transitions must return explicit non-2xx JSON errors and be visible in the UI.
- Product-specific cold-chain operations-ledger surface at 1440x1024 and 390x844, including loading, no-selection, filtered-empty, validation/error, active-incident, and resolved feedback.
- Local-only language; no login, containers, CI, hashes, external dispatch, generic framework layers, or speculative integrations.

Acceptance evidence: passing API/domain tests including restart and illegal transitions; a real Chromium UI -> HTTP API -> SQLite -> visible-result journey; restart query of browser-written state; desktop/mobile screenshots; console/page/request and horizontal-overflow checks.

## Delegation record

- Stable implementation package delegated once to `/root/development_v2_e2e/relay_north_impl`, requested model `gpt-5.6-luna`, bounded to `/tmp/development-v2-e2e/project`.
- Child delivered `app.py`, `static/`, `tests/test_app.py`, and `README.md`; child status: completed.
- Top-level integrated the package, added `tests/browser_e2e.mjs`, ran all direct oracles, inspected the real screenshots independently, and created this trace.
- Actual model/token/WCU telemetry was not independently audited: `[UNCERTAIN]`.

## Commands and results

```sh
python3 -m py_compile app.py
node --check static/app.js
python3 -m unittest discover -s tests -v
```

Result: syntax checks passed; 4/4 unittest cases passed in 0.191s. Covered multiple seeded shipments, legal lifecycle, required disposition, explicit 409 illegal transition, audit append behavior, and a real server restart using the same SQLite file.

```sh
RELAY_DB_PATH=/tmp/relay-north-e2e.p6N76m/relay.sqlite3 python3 app.py --port 18333
CHROMIUM_PATH=/tmp/chromium \
PUPPETEER_CORE_MODULE=file:///tmp/frontend-eval-browser-runtime/node_modules/puppeteer-core/lib/esm/puppeteer/puppeteer-core.js \
RELAY_BASE_URL=http://127.0.0.1:18333 node tests/browser_e2e.mjs
```

Result: browser journey passed. It observed initial no-selection and four shipments, selected the open RN-24081 incident, proved a stale UI action surfaced the server's `409` message, proved the resolve form blocked a missing disposition, resolved with `held`, then read back `resolved`, `held`, and 3 audit events from the API. Desktop and mobile horizontal overflow were both 0px. Page errors: 0. Failed requests: 0. Unexpected console errors: 0. Chromium logged one expected `409 (Conflict)` resource error for the deliberately exercised illegal transition.

```sh
RELAY_DB_PATH=/tmp/relay-north-e2e.p6N76m/relay.sqlite3 python3 app.py --port 18334
curl http://127.0.0.1:18334/api/shipments/RN-24081
curl http://127.0.0.1:18334/api/shipments/RN-24081/audit
```

Result after stopping the browser-run server and starting a new process: `restart_state=resolved`, `restart_disposition=held`, `restart_audit_events=3`, newest event `incident_resolved`.

```sh
file artifacts/*.png
```

Result: `relay-desktop-active.png` and `relay-desktop-resolved.png` are 1440x1024; `relay-mobile-390x844.png` is 390x844; `relay-mobile-resolved.png` is a 390px-wide full-page capture. Independent visual inspection found a readable cold-chain manifest/route/timeline hierarchy at both target viewports with no blocking visual defect.

## Decisive evidence

- UI -> API -> SQLite -> visible resolved state completed in real Chromium.
- The browser-visible illegal-transition text was: `Cannot acknowledge an incident in acknowledged state; next legal action is resolve`.
- The browser-visible validation text was: `Choose a disposition before resolving.`
- A separate server process returned the browser-written resolved state and all 3 audit events from the same SQLite file.
- Screenshots show the active and resolved incident states, local-only language, product-specific manifest, cold-chain temperatures, clinic route strip, and audit trail.
- Scope check found only local HTTP URLs and explicit no-external-dispatch language; the delivered app has no third-party runtime dependency.
- Drift/fallback review: no auth, deployment, containers, CI, external integration, or speculative abstraction was added. API errors stay non-2xx and the UI reports them; server/UI error handling does not substitute placeholder success.
- Git/deployment/external state: the workspace is not a Git repository; no commit, push, deployment, or external dispatch occurred.

## Honest limitations

- Relay North is intentionally single-user and local-only. It does not contact clinics, carriers, or dispatch systems.
- Seed shipment readings and routes are local demonstration records, not live sensor or carrier data.
- The expected 409 exercised during the browser error journey appears once in Chromium's console as a failed resource; there were no unexpected console, page, or request failures.
- Runtime provenance/WCU is `[UNCERTAIN]`; product acceptance rests on the direct test, browser, screenshot, API, and restart evidence above.
- The SOP did not allow a shallow demo to be called complete: completion required the real frontend/API/SQLite boundary, legal and illegal state paths, restart persistence, and render-oracle evidence recorded above.
