#!/usr/bin/env python3
"""Relay North: a small, local-only cold-chain incident coordination ledger."""
from __future__ import annotations

import argparse
import json
import os
import sqlite3
import threading
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("RELAY_DB_PATH", ROOT / "data" / "relay_north.sqlite3"))
STATIC = ROOT / "static"
VALID_DISPOSITIONS = {"released", "held", "discarded", "returned", "transferred"}
STATE_LABELS = {"none": "No incident", "open": "Open", "acknowledged": "Acknowledged", "resolved": "Resolved"}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db


def init_db() -> None:
    with connect() as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS shipments (
                id TEXT PRIMARY KEY,
                reference TEXT NOT NULL,
                product TEXT NOT NULL,
                origin TEXT NOT NULL,
                destination TEXT NOT NULL,
                route TEXT NOT NULL,
                temp_min REAL NOT NULL,
                temp_max REAL NOT NULL,
                current_temp REAL NOT NULL,
                temp_unit TEXT NOT NULL DEFAULT '°C',
                eta TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'in_transit',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS incidents (
                shipment_id TEXT PRIMARY KEY REFERENCES shipments(id),
                state TEXT NOT NULL CHECK(state IN ('open','acknowledged','resolved')),
                opened_at TEXT NOT NULL,
                acknowledged_at TEXT,
                resolved_at TEXT,
                disposition TEXT
            );
            CREATE TABLE IF NOT EXISTS audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                shipment_id TEXT NOT NULL REFERENCES shipments(id),
                event_type TEXT NOT NULL,
                message TEXT NOT NULL,
                actor TEXT NOT NULL,
                metadata TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS audit_shipment_time ON audit(shipment_id, id DESC);
            """
        )
        if db.execute("SELECT COUNT(*) FROM shipments").fetchone()[0] == 0:
            seed(db)


def seed(db: sqlite3.Connection) -> None:
    stamp = now()
    rows = [
        ("RN-24081", "Vaccine / Varicella", "North Harbor Hub", "St. Anselm Clinic", "NH-04 → SA-17", 2, 8, 9.4, "2026-08-12 14:20", "at_risk"),
        ("RN-24082", "Insulin / Cold pack", "North Harbor Hub", "Riverside Community", "NH-04 → RC-09", 2, 8, 5.8, "2026-08-12 16:05", "in_transit"),
        ("RN-24083", "Biologic / Adalimumab", "East Crossdock", "Mabini District Clinic", "EC-02 → MD-22", 2, 8, 3.6, "2026-08-12 18:40", "in_transit"),
        ("RN-24084", "Vaccine / MMR", "North Harbor Hub", "Portside Health Center", "NH-04 → PH-03", 2, 8, 4.1, "2026-08-12 20:15", "in_transit"),
    ]
    for item in rows:
        db.execute(
            "INSERT INTO shipments (id,reference,product,origin,destination,route,temp_min,temp_max,current_temp,temp_unit,eta,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?, ?,?,?)",
            (item[0], item[0], item[1], item[2], item[3], item[4], item[5], item[6], item[7], "°C", item[8], item[9], stamp, stamp),
        )
    db.execute("INSERT INTO incidents (shipment_id,state,opened_at) VALUES (?,?,?)", ("RN-24081", "open", stamp))
    db.execute("UPDATE shipments SET updated_at=? WHERE id=?", (stamp, "RN-24081"))
    db.execute(
        "INSERT INTO audit (shipment_id,event_type,message,actor,metadata,created_at) VALUES (?,?,?,?,?,?)",
        ("RN-24081", "incident_opened", "Temperature excursion detected at North Harbor Hub", "Relay North monitor", json.dumps({"temperature": 9.4, "threshold": "2–8°C"}), stamp),
    )


def shipment_dict(db: sqlite3.Connection, sid: str) -> dict | None:
    row = db.execute(
        "SELECT s.*, i.state AS incident_state, i.opened_at, i.acknowledged_at, i.resolved_at, i.disposition FROM shipments s LEFT JOIN incidents i ON i.shipment_id=s.id WHERE s.id=?",
        (sid,),
    ).fetchone()
    if not row:
        return None
    data = dict(row)
    state = data.pop("incident_state") or "none"
    data["incident"] = {"state": state, "label": STATE_LABELS[state]}
    for key in ("opened_at", "acknowledged_at", "resolved_at", "disposition"):
        value = data.pop(key)
        data["incident"][key] = value
    data["temperature_status"] = "above_range" if data["current_temp"] > data["temp_max"] else ("below_range" if data["current_temp"] < data["temp_min"] else "in_range")
    return data


def list_shipments(db: sqlite3.Connection, query: str = "") -> list[dict]:
    rows = db.execute("SELECT id FROM shipments ORDER BY CASE status WHEN 'at_risk' THEN 0 ELSE 1 END, eta").fetchall()
    result = []
    for row in rows:
        item = shipment_dict(db, row["id"])
        if query and query.lower() not in " ".join(str(item.get(k, "")) for k in ("id", "reference", "product", "origin", "destination", "status" )).lower():
            continue
        result.append(item)
    return result


def audit_for(db: sqlite3.Connection, sid: str) -> list[dict]:
    rows = db.execute("SELECT id,event_type,message,actor,metadata,created_at FROM audit WHERE shipment_id=? ORDER BY id DESC", (sid,)).fetchall()
    result = []
    for row in rows:
        item = dict(row)
        try:
            item["metadata"] = json.loads(item["metadata"])
        except json.JSONDecodeError:
            pass
        result.append(item)
    return result


class DomainError(Exception):
    def __init__(self, message: str, status: int = 422, code: str = "invalid_request"):
        super().__init__(message)
        self.message, self.status, self.code = message, status, code


def transition(sid: str, action: str, body: dict) -> dict:
    action = action.lower().strip()
    aliases = {"start": "open", "open": "open", "ack": "acknowledge", "acknowledged": "acknowledge", "resolve": "resolve", "resolved": "resolve"}
    action = aliases.get(action, action)
    with connect() as db:
        current = shipment_dict(db, sid)
        if current is None:
            raise DomainError("Shipment not found", 404, "not_found")
        state = current["incident"]["state"]
        legal = {"none": "open", "open": "acknowledge", "acknowledged": "resolve"}
        expected = legal.get(state)
        if action != expected:
            raise DomainError(f"Cannot {action} an incident in {state} state; next legal action is {expected or 'none'}", 409, "illegal_transition")
        stamp = now()
        if action == "open":
            db.execute("INSERT INTO incidents (shipment_id,state,opened_at) VALUES (?,?,?)", (sid, "open", stamp))
            event, message = "incident_opened", body.get("message") or "Incident opened for review"
            metadata = {"source": "coordinator"}
        elif action == "acknowledge":
            db.execute("UPDATE incidents SET state='acknowledged',acknowledged_at=? WHERE shipment_id=?", (stamp, sid))
            event, message, metadata = "incident_acknowledged", body.get("message") or "Coordinator acknowledged the excursion", {"source": "coordinator"}
        else:
            disposition = str(body.get("disposition", "")).strip().lower()
            if disposition not in VALID_DISPOSITIONS:
                raise DomainError("A valid disposition is required: released, held, discarded, returned, or transferred", 422, "invalid_disposition")
            db.execute("UPDATE incidents SET state='resolved',resolved_at=?,disposition=? WHERE shipment_id=?", (stamp, disposition, sid))
            event, message, metadata = "incident_resolved", body.get("message") or f"Incident resolved: {disposition}", {"disposition": disposition, "source": "coordinator"}
        db.execute("UPDATE shipments SET updated_at=? WHERE id=?", (stamp, sid))
        db.execute("INSERT INTO audit (shipment_id,event_type,message,actor,metadata,created_at) VALUES (?,?,?,?,?,?)", (sid, event, message, "Regional coordinator", json.dumps(metadata), stamp))
        return {"shipment": shipment_dict(db, sid), "audit": audit_for(db, sid)}


class Handler(BaseHTTPRequestHandler):
    server_version = "RelayNorth/1.0"

    def log_message(self, fmt, *args):
        return

    def send_json(self, payload: dict, status: int = 200):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length == 0:
            return {}
        try:
            value = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(value, dict):
                raise ValueError
            return value
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
            raise DomainError("Request body must be a JSON object", 400, "invalid_json")

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        if path.startswith("/api"):
            try:
                with connect() as db:
                    if path == "/api/health":
                        self.send_json({"ok": True, "service": "relay-north", "local_only": True})
                    elif path == "/api/shipments":
                        query = parse_qs(parsed.query).get("q", [""])[0]
                        items = list_shipments(db, query)
                        self.send_json({"shipments": items, "count": len(items)})
                    else:
                        parts = path.split("/")
                        sid = parts[3] if len(parts) > 3 else ""
                        item = shipment_dict(db, sid)
                        if item is None:
                            raise DomainError("Shipment not found", 404, "not_found")
                        if len(parts) == 4:
                            self.send_json({"shipment": item})
                        elif len(parts) == 5 and parts[4] in ("audit", "timeline"):
                            self.send_json({"shipment_id": sid, "audit": audit_for(db, sid)})
                        else:
                            raise DomainError("API route not found", 404, "not_found")
            except DomainError as exc:
                self.send_json({"error": {"code": exc.code, "message": exc.message}}, exc.status)
            except Exception as exc:
                self.send_json({"error": {"code": "server_error", "message": str(exc)}}, 500)
            return
        self.serve_static(path)

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/")
        if not path.startswith("/api/"):
            self.send_json({"error": {"code": "not_found", "message": "API route not found"}}, 404)
            return
        try:
            body = self.read_json()
            parts = path.split("/")
            sid, action = "", ""
            if len(parts) >= 6 and parts[1:5] == ["api", "shipments", parts[3], "incident"]:
                sid, action = parts[3], parts[5]
            elif len(parts) >= 5 and parts[1:4] == ["api", "shipments", parts[3]]:
                sid, action = parts[3], parts[4]
            elif len(parts) >= 5 and parts[1:3] == ["api", "incidents"]:
                sid, action = parts[3], parts[4]
            elif len(parts) == 4 and parts[1:3] == ["api", "shipments"]:
                sid, action = parts[3], body.get("action", "")
            else:
                raise DomainError("API route not found", 404, "not_found")
            if action == "incident":
                action = body.get("action", "")
            if not action:
                raise DomainError("An incident action is required", 400, "missing_action")
            result = transition(sid, action, body)
            self.send_json(result, 200)
        except DomainError as exc:
            self.send_json({"error": {"code": exc.code, "message": exc.message}}, exc.status)
        except Exception as exc:
            self.send_json({"error": {"code": "server_error", "message": str(exc)}}, 500)

    def serve_static(self, path: str):
        relative = "index.html" if path == "/" else path.lstrip("/")
        if relative.startswith("static/"):
            relative = relative[7:]
        target = (STATIC / relative).resolve()
        if STATIC not in target.parents or not target.is_file():
            self.send_json({"error": {"code": "not_found", "message": "Page not found"}}, 404)
            return
        content_type = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8"}.get(target.suffix, "application/octet-stream")
        data = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the local Relay North ledger")
    parser.add_argument("--host", default=os.environ.get("RELAY_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("RELAY_PORT", "8080")))
    args = parser.parse_args()
    init_db()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Relay North listening at http://{args.host}:{args.port} (local-only)", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
