import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

const puppeteerModule = process.env.PUPPETEER_CORE_MODULE;
const chromiumPath = process.env.CHROMIUM_PATH;
const baseUrl = process.env.RELAY_BASE_URL || 'http://127.0.0.1:18333';
if (!puppeteerModule || !chromiumPath) throw new Error('Browser oracle paths are required');

const { default: puppeteer } = await import(puppeteerModule);
await fs.mkdir(new URL('../artifacts/', import.meta.url), { recursive: true });
const browser = await puppeteer.launch({
  executablePath: chromiumPath,
  headless: true,
  args: ['--no-sandbox', '--disable-dev-shm-usage'],
});

const consoleErrors = [];
const pageErrors = [];
const failedRequests = [];

function observe(page) {
  page.on('console', message => {
    if (message.type() === 'error') consoleErrors.push(message.text());
  });
  page.on('pageerror', error => pageErrors.push(error.message));
  page.on('requestfailed', request => failedRequests.push(`${request.method()} ${request.url()} ${request.failure()?.errorText}`));
}

async function text(page, selector) {
  return page.$eval(selector, element => element.textContent.trim());
}

try {
  const desktop = await browser.newPage();
  observe(desktop);
  await desktop.setViewport({ width: 1440, height: 1024, deviceScaleFactor: 1 });
  await desktop.goto(baseUrl, { waitUntil: 'networkidle0' });
  await desktop.waitForFunction(() => document.querySelectorAll('.shipment-row').length === 4);
  assert.match(await text(desktop, '#detail'), /Select a shipment/);
  assert.match(await text(desktop, '.workspace-note'), /Local-only workspace/);

  await desktop.click('[data-id="RN-24081"]');
  await desktop.waitForSelector('[data-action="acknowledge"]');
  assert.match(await text(desktop, '#detail'), /Temperature excursion detected/);
  await desktop.screenshot({ path: new URL('../artifacts/relay-desktop-active.png', import.meta.url).pathname, fullPage: true });
  const desktopOverflow = await desktop.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  assert.ok(desktopOverflow <= 0, `desktop horizontal overflow: ${desktopOverflow}px`);

  // Simulate another local tab acknowledging while this rendered view is stale,
  // then use the visible stale action to prove the UI surfaces the server's 409.
  const firstAck = await desktop.evaluate(async () => {
    const response = await fetch('/api/shipments/RN-24081/incident/acknowledge', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}',
    });
    return { status: response.status, body: await response.json() };
  });
  assert.equal(firstAck.status, 200);
  await desktop.click('[data-action="acknowledge"]');
  await desktop.waitForFunction(() => document.querySelector('#toast.error')?.textContent.includes('Cannot acknowledge'));
  const illegalMessage = await text(desktop, '#toast');
  assert.match(illegalMessage, /next legal action is resolve/);

  await desktop.click('[data-id="RN-24081"]');
  await desktop.waitForSelector('[data-action="resolve"]');
  await desktop.click('[data-action="resolve"]');
  await desktop.waitForSelector('#confirm-resolve');
  await desktop.click('#confirm-resolve');
  await desktop.waitForFunction(() => document.querySelector('#toast.error')?.textContent.includes('Choose a disposition'));
  const validationMessage = await text(desktop, '#toast');
  assert.match(validationMessage, /Choose a disposition/);
  await desktop.select('#disposition', 'held');
  await desktop.type('#resolution-note', 'Held for clinic cold-chain review.');
  await desktop.click('#confirm-resolve');
  await desktop.waitForFunction(() => document.querySelector('#detail')?.textContent.includes('Disposition: held'));
  assert.match(await text(desktop, '#detail'), /incident resolved/i);

  const persisted = await desktop.evaluate(async () => (await fetch('/api/shipments/RN-24081')).json());
  const audit = await desktop.evaluate(async () => (await fetch('/api/shipments/RN-24081/audit')).json());
  assert.equal(persisted.shipment.incident.state, 'resolved');
  assert.equal(persisted.shipment.incident.disposition, 'held');
  assert.equal(audit.audit.length, 3);
  await desktop.screenshot({ path: new URL('../artifacts/relay-desktop-resolved.png', import.meta.url).pathname, fullPage: true });

  const mobile = await browser.newPage();
  observe(mobile);
  await mobile.setViewport({ width: 390, height: 844, deviceScaleFactor: 1 });
  await mobile.goto(baseUrl, { waitUntil: 'networkidle0' });
  await mobile.waitForFunction(() => document.querySelectorAll('.shipment-row').length === 4);
  await mobile.click('[data-id="RN-24081"]');
  await mobile.waitForFunction(() => document.querySelector('#detail')?.textContent.includes('Disposition: held'));
  const mobileOverflow = await mobile.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  assert.ok(mobileOverflow <= 0, `mobile horizontal overflow: ${mobileOverflow}px`);
  await mobile.screenshot({ path: new URL('../artifacts/relay-mobile-resolved.png', import.meta.url).pathname, fullPage: true });
  await mobile.$eval('#detail', element => element.scrollIntoView({ block: 'start' }));
  await mobile.screenshot({ path: new URL('../artifacts/relay-mobile-390x844.png', import.meta.url).pathname });

  const expectedConsoleErrors = consoleErrors.filter(message => message.includes('409 (Conflict)'));
  const unexpectedConsoleErrors = consoleErrors.filter(message => !message.includes('409 (Conflict)'));
  assert.equal(expectedConsoleErrors.length, 1);
  assert.deepEqual(unexpectedConsoleErrors, []);
  assert.deepEqual(pageErrors, []);
  assert.deepEqual(failedRequests, []);
  console.log(JSON.stringify({
    journey: 'no-selection -> open incident detail -> stale illegal transition -> validation -> resolved',
    shipments: 4,
    final_state: persisted.shipment.incident.state,
    disposition: persisted.shipment.incident.disposition,
    audit_events: audit.audit.length,
    illegal_transition_visible: illegalMessage,
    validation_visible: validationMessage,
    desktop_overflow_px: desktopOverflow,
    mobile_overflow_px: mobileOverflow,
    expected_console_errors: expectedConsoleErrors.length,
    unexpected_console_errors: unexpectedConsoleErrors.length,
    page_errors: pageErrors.length,
    failed_requests: failedRequests.length,
  }, null, 2));
} finally {
  await browser.close();
}
