import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from http.client import HTTPConnection
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]


class RelayNorthHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db = Path(cls.tmp.name) / "relay.sqlite3"
        cls.port = 18765
        env = {**os.environ, "RELAY_DB_PATH": str(cls.db), "PYTHONUNBUFFERED": "1"}
        cls.proc = subprocess.Popen([sys.executable, "app.py", "--host", "127.0.0.1", "--port", str(cls.port)], cwd=PROJECT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(60):
            try:
                cls.request("GET", "/api/health")
                break
            except (ConnectionRefusedError, ConnectionResetError):
                time.sleep(.05)
        else:
            raise RuntimeError("server did not start")

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate(); cls.proc.wait(timeout=3); cls.tmp.cleanup()

    @classmethod
    def request(cls, method, path, body=None):
        conn = HTTPConnection("127.0.0.1", cls.port, timeout=3)
        payload = None if body is None else json.dumps(body)
        conn.request(method, path, payload, {"Content-Type": "application/json"} if payload is not None else {})
        response = conn.getresponse(); data = json.loads(response.read()); conn.close()
        return response.status, data

    def test_seed_has_multiple_shipments_and_open_incident(self):
        status, payload = self.request("GET", "/api/shipments")
        self.assertEqual(status, 200); self.assertGreaterEqual(payload["count"], 3)
        first = next(s for s in payload["shipments"] if s["id"] == "RN-24081")
        self.assertEqual(first["incident"]["state"], "open")

    def test_legal_lifecycle_and_resolution_validation(self):
        self.assertEqual(self.request("POST", "/api/shipments/RN-24082/incident/start", {})[0], 200)
        self.assertEqual(self.request("POST", "/api/shipments/RN-24082/incident/acknowledge", {})[0], 200)
        status, error = self.request("POST", "/api/shipments/RN-24082/incident/resolve", {})
        self.assertEqual(status, 422); self.assertEqual(error["error"]["code"], "invalid_disposition")
        status, result = self.request("POST", "/api/shipments/RN-24082/incident/resolve", {"disposition": "held"})
        self.assertEqual(status, 200); self.assertEqual(result["shipment"]["incident"]["state"], "resolved")
        self.assertEqual(len(result["audit"]), 3)

    def test_illegal_transition_is_explicit_error(self):
        status, payload = self.request("POST", "/api/shipments/RN-24081/incident/start", {})
        self.assertEqual(status, 409); self.assertEqual(payload["error"]["code"], "illegal_transition")

    def test_audit_is_append_only_and_persists_after_restart(self):
        status, payload = self.request("GET", "/api/shipments/RN-24081/audit")
        self.assertEqual(status, 200); before = len(payload["audit"])
        self.__class__.proc.terminate(); self.__class__.proc.wait(timeout=3)
        env = {**os.environ, "RELAY_DB_PATH": str(self.db), "PYTHONUNBUFFERED": "1"}
        self.__class__.proc = subprocess.Popen([sys.executable, "app.py", "--host", "127.0.0.1", "--port", str(self.port)], cwd=PROJECT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(60):
            try:
                status, payload = self.request("GET", "/api/shipments/RN-24081/audit")
                if status == 200: break
            except (ConnectionRefusedError, ConnectionResetError): time.sleep(.05)
        self.assertEqual(len(payload["audit"]), before)


if __name__ == "__main__":
    unittest.main()
