# Relay North

Relay North is a local-only cold-chain coordination ledger for a regional clinic coordinator. It provides a shipment manifest, route and temperature context, one incident lifecycle per shipment, and an append-only audit timeline. It never contacts carriers, clinics, or external dispatch systems.

## Run

From this directory, with Python 3.10+:

```sh
python3 app.py
```

Open <http://127.0.0.1:8080>. The SQLite file is created at `data/relay_north.sqlite3` and survives server restarts. To use another database while testing, set `RELAY_DB_PATH=/absolute/path/to/relay.sqlite3`.

## HTTP API

```sh
curl http://127.0.0.1:8080/api/shipments
curl http://127.0.0.1:8080/api/shipments/RN-24081
curl http://127.0.0.1:8080/api/shipments/RN-24081/audit
curl -X POST http://127.0.0.1:8080/api/shipments/RN-24082/incident/start -H 'Content-Type: application/json' -d '{}'
curl -X POST http://127.0.0.1:8080/api/shipments/RN-24082/incident/acknowledge -H 'Content-Type: application/json' -d '{}'
curl -X POST http://127.0.0.1:8080/api/shipments/RN-24082/incident/resolve -H 'Content-Type: application/json' -d '{"disposition":"held"}'
```

The only legal transitions are `none → open → acknowledged → resolved`. Resolution requires one of `released`, `held`, `discarded`, `returned`, or `transferred`. Invalid JSON, missing dispositions, unknown shipments, and illegal transitions return a JSON `error` object with a non-2xx status.

## Tests

```sh
python3 -m unittest discover -s tests -v
```
